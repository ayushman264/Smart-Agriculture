import React from 'react';
import Cards from 'react-credit-cards';
import 'react-credit-cards/es/styles-compiled.css';
import './payment.css';
import paymentwallpaper from '../paymentwallpaper.jpg';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import StripeCheckout from 'react-stripe-checkout';

export default class payment extends React.Component {
  state = {
    cvc: '',
    expiry: '',
    focus: '',
    name: '',
    number: '',
  };
 
  handleInputFocus = (e) => {
    this.setState({ focus: e.target.name });
  }
  
  handleInputChange = (e) => {
    const { name, value } = e.target;
    
    this.setState({ [name]: value });
  }
  
  render() {

function handleToken(token,addresses){

}
  

    return (
      <body>
      <div className="navbar1">
          <ul>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/reqsensor">Request New Sensor</Link></li>
            <li><Link to="/reqsensor">View Sensor Status</Link></li>
            <li><Link to="/reqsensor">View Sensor Location</Link></li>
           <li><Link to="#">Logout</Link></li>
          </ul>
          </div>
      <div id="PaymentForm" className="body">

      <h1 className="header"> Payments Pay Here!</h1>
        <Cards
          cvc={this.state.cvc}
          expiry={this.state.expiry}
          focus={this.state.focus}
          name={this.state.name}
          number={this.state.number}/>
        <form className="form">
        <br/>
          <input
            type="tel"
            name="number"
            placeholder="Card Number"
            maxlength="16"
            onChange={this.handleInputChange}
            onFocus={this.handleInputFocus}/>
            <br/>
          <input
            type="tel"
            name="name"
            placeholder="Card Name"
            onChange={this.handleInputChange}
            onFocus={this.handleInputFocus}/>
            <br/>
          <input
            type="tel"
            name="cvc"
            placeholder="Card CVC"
            maxlength="3"
            onChange={this.handleInputChange}
            onFocus={this.handleInputFocus}/>
            <br/>
          <input
            type="tel"
            name="expiry"
            placeholder="Card expiry"
            maxlength="4"
            onChange={this.handleInputChange}
            onFocus={this.handleInputFocus}/>
            <br/>
            <br/>
            
          <button><Link to="/home">Submit</Link></button>
        </form>
        <StripeCheckout stripeKey="pk_test_ivzM5QukwthiMrGmUKnG43ej00xMMfVngZ"
    token="{handleToken}"/>
      </div>
      </body>
    );
  }
}
