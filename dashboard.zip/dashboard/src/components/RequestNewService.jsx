import React, { Component } from 'react';
import './RequestNewService.css';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
class RequestNewService extends Component {


    render() {
        return (
          <div className = "page">
          <div className="navbar1">
          <ul>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/reqsensor">Request New Sensor</Link></li>
            <li><Link to="/reqsensor">View Sensor Status</Link></li>
            <li><Link to="/reqsensor">View Sensor Location</Link></li>
           <li><Link to="#">Logout</Link></li>
          </ul>
          </div>
            <h1><center>View available Services</center></h1>
            <table>
              <tr>
                <th>Select</th>
                <th>Service</th>
                <th>Description</th>
                <th>Price(/hr)</th>
                </tr>
              <tr>
                <td><input type="radio" name="sensorservice" value="100" /></td>
                <td>Service 1</td>
                <td>5 tractor 12 sensors</td>
                <td>$100</td>
              </tr>

              <tr>
              <td><input type="radio" name="sensorservice" value="75" /></td>
                <td>Service 2</td>
                <td>4 tractor 9 sensors</td>
                <td>$75</td>
              </tr>

              <tr>
              <td><input type="radio" name="sensorservice" value="60" /></td>
                <td>Service 3</td>
                <td>3 tractor 7 sensors</td>
                <td>$60</td>
              </tr>

              <tr>
              <td><input type="radio"  name="sensorservice" value="55" /></td>
                <td>Service 4</td>
                <td>2 tractor 6 sensors</td>
                <td>$55</td>
              </tr>
            </table>

            <center><button className="btn btn-success">Request New Service</button></center>



          </div>
        );
    }


}



export default RequestNewService;
