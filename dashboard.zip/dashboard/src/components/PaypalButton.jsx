import React from 'react';
import ReactDOM from 'react-dom';
import scriptLoader from 'react-async-script-loader';
import PaypalExpressBtn from 'react-paypal-express-checkout';
import StripeCheckout from 'react-stripe-checkout';


 
class PaypalButton extends React.Component {


  render() {
    
function handleToken(token,addresses){

}
        return (
    <div>
    <StripeCheckout stripeKey="pk_test_ivzM5QukwthiMrGmUKnG43ej00xMMfVngZ"
    token="{handleToken}"/>
    </div>
        );
};

}
 
export default PaypalButton;