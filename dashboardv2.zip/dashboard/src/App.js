import React from 'react';
// import logo from './logo.svg';
import Dashboard from './components/Dashboard.jsx';
import RequestNewService from './components/RequestNewService';
import RequestNewMachine from './components/RequestNewMachine';
import RequestNewSensor from './components/RequestNewSensor';
import ViewSensorLocation from './components/ViewSensorLocation';
import Register from './components/register';
import Login from './components/Login';
import payment from './components/payment';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import './App.css';

function App() {
  return (
    <Router>
    <div className = "parent" >
    <Route path = "/" exact strict component = {Login} />
    <Route path = "/register" exact strict component = {Register} />
    <Route path = "/home" exact strict component = {Dashboard} />
    <Route path = "/reqservice" exact strict component = {RequestNewService} />
    <Route path = "/reqsensor" exact strict component = {RequestNewSensor} />
    <Route path = "/payment" exact strict component = {payment} />
    <Route path = "/reqmachine" exact strict component = {RequestNewMachine} />
    <Route path = "/viewsensorlocation" exact strict component = {ViewSensorLocation} />
    </div>
    </Router>
  );
}

export default App;
