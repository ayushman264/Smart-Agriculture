import React, { Component } from 'react';

import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
import {Map, InfoWindow, Marker, GoogleApiWrapper} from 'google-maps-react';

class ViewSensorLocation extends Component {


    render() {
        return (
          <div className = "vsl-page">
            <div className="navbar1">
            <ul>
              <li><Link to="/home">Home</Link></li>
              <li><Link to="/reqsensor">Request New Sensor</Link></li>
              <li><Link to="/reqsensor">View Sensor Status</Link></li>
              <li><Link to="/viewsensorlocation">View Sensor Location</Link></li>
              <li><Link to="/payment">Payment</Link></li>
             <li><Link to="/">Logout</Link></li>
            </ul>
            </div>
            <div className="showMap">
            <Map google={this.props.google} initialCenter ={{lat: 37.347834, lng: -121.7040562}} zoom={13}>

                <Marker
            title={'Sensor1'}
            name={'Current location'}
            position={{lat: 37.347834, lng: -121.7040562}} />

            <Marker
        title={'Sensor2'}
        name={'Current location'}
        position={{lat:   37.363963, lng:  -121.725847}} />

        <Marker
    title={'Sensor3'}
    name={'Current location'}
    position={{lat: 37.3295384, lng: -121.7151004}} />

    <Marker
title={'Sensor4'}
name={'Current location'}
position={{lat: 37.366501, lng:  -121.695860}} />


<Marker
title={'Sensor5'}
name={'Current location'}
position={{lat: 37.3568484, lng: -121.694531}} />


<Marker
title={'Sensor6'}
name={'Current location'}
position={{lat: 37.341276, lng: -121.690425}} />

<Marker
title={'Sensor7'}
name={'Current location'}
position={{lat: 37.321006, lng: -121.680132}} />

      </Map>
      </div>
          </div>
          );
    }


}





export default GoogleApiWrapper({
  apiKey: ("AIzaSyBOiYszryMQUwc-kRzCzUOdU6hTy0ZTIs4")
})(ViewSensorLocation);
