import React,{ Component } from 'react';
import wallpaper1 from './wallpaper1.jpg';
import './Login.css';
import Dashboard from './Dashboard.jsx';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

import Register from './register';
class Login extends Component{

state = { firstName:"",
	   	  password:"",
	   	  answer:"",
				incorrectCredentials: ""
		 };


validate = () => {
	let incorrectCredentials = "";
	if(this.state.firstName !== 'abcd' && this.state.password !== '1234')
		incorrectCredentials = "Incorrect Credentials";
	if(incorrectCredentials){
		this.setState({incorrectCredentials});
		return false;
	}

	return true;
};

onLogin = e =>{
	e.preventDefault();
	this.setState({answer:this.state.firstName+" "+this.state.password});
	//console.log(this.state.answer);
	//console.log(this.state);
	const isValid = this.validate();
	if(isValid){
		console.log(this.state);
		this.setState({firstName: ""});
		this.setState({password: ""});
	}
};

onRegister = e =>{
	e.preventDefault();

}

	render(){
		return (
			<div className="mybody">
			<div className="login-box">

			<form className="loginformdetails">
			<h3 className="loginheader">Login</h3>

			<div style={{ fontSize: 12, color: "red" }}>
            {this.state.incorrectCredentials ? "Incorrect Credentials" : ""}
						</div>
			<div className="details">
			<h4>Username</h4>
			<input
			placeholder="Enter Username"
			type="text"
			value={this.state.firstName}
			className="form-control"
			onChange={e=>this.setState({firstName:e.target.value})}/>
			<br/>

			<h4>Password</h4>
			<input
			placeholder="Enter Password"
			type="password"
			value={this.state.password}
			className="form-control"
			onChange={e=>this.setState({password:e.target.value})}/>
			<br/>

			<button className="btn btn-success"  onClick={e=>this.onLogin(e)}><Link to="/home" className="mylink">Login</Link></button>
			<br/><br/>
			<button className="btn btn-success"><a href="/register" className="mylink">Register</a></button>

			<br/>
			<br/>
			<input
			placeholder="Final answer"
			type="text"
			value={this.state.answer}
			onChange={e=>this.setState({answer:e.target.value})}/>

			</div>

			</form>
			</div>
			</div>
		);
	}


}



export default Login;
