import React,{ Component } from 'react';
import wallpaper1 from './wallpaper1.jpg';
import './register.css';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

class Register extends Component{

state = { name:"",
		  email:"",
		  number:"",
	   	  password:"",
	   	  answer:""
		 };

onRegister = e =>{
	e.preventDefault();
	this.setState({answer:this.state.firstName+" "+this.state.password});
	//console.log(this.state.answer);
	//console.log(this.state);
};

onRegister = e =>{
	e.preventDefault();

}

	render(){
		return (
			<div className="mybody">
			<div className="register-box">

			<form className="registerformdetails">
			<h3 className="loginheader">Register</h3>

			<h4>User Type</h4> <select name="usertype">
                    <option value="Farmer">Farmer</option>
                    <option value="Machine Controller">Machine Controller</option>
            </select>

			<h4>Name</h4>
			<input
			placeholder="Enter Name"
			type="text"
			value={this.state.name}
			class="form-control"
			onChange={e=>this.setState({name:e.target.value})}/>


			<h4>Contact Number</h4>
			<input
			placeholder="Enter Contact Number"
			type="text"
			value={this.state.number}
			class="form-control"
			onChange={e=>this.setState({number:e.target.value})}/>


			<h4>Email</h4>
			<input
			placeholder="Enter Email-id"
			type="text"
			value={this.state.email}
			class="form-control"
			onChange={e=>this.setState({email:e.target.value})}/>


			<h4>Password</h4>
			<input
			placeholder="Enter Password"
			type="password"
			value={this.state.password}
			class="form-control"
			onChange={e=>this.setState({password:e.target.value})}/>

			<h4>Location</h4> <select name="location">
                    <option value="37.3382,-121.8863">San Jose</option>
                    <option value="37.7749,-122.4194">San Francisco</option>
                    <option value="40.7128,-74.0060">New York</option>
            </select>

			<button className="btn btn-success" width onClick={e=>this.onRegister(e)}>Register</button>




			<br/>
			<input
			placeholder="Final answer"
			type="text"
			value={this.state.answer}
			onChange={e=>this.setState({answer:e.target.value})}/>



			</form>

			</div>
			</div>

		);
	}


}



export default Register;
