import React, { Component } from 'react';
import './RequestNewSensor.css';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';
class RequestNewSensor extends Component {


    render() {
        return (
          <div className = "reqsensorpage">
          <div className="navbar1">
          <ul>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/reqsensor">Request New Sensor</Link></li>
            <li><Link to="/reqsensor">View Sensor Status</Link></li>
            <li><Link to="/viewsensorlocation">View Sensor Location</Link></li>
            <li><Link to="/payment">Payment</Link></li>
           <li><Link to="/">Logout</Link></li>
          </ul>
          </div>
            <h1><center>View available Sensors</center></h1>
            <table>
              <tr>
                <th>Select</th>
                <th>Sensor</th>
                <th>Description</th>
                <th>Price(/hr)</th>
                </tr>
              <tr>
                <td><input type="radio" name="machine" value="100" /></td>
                <td>Temperature</td>
                <td>Shows Temperature Reading</td>
                <td>$100</td>
              </tr>

              <tr>
              <td><input type="radio" name="machine" value="75" /></td>
                <td>Pressure</td>
                <td>Shows Pressure readings</td>
                <td>$75</td>
              </tr>

              <tr>
              <td><input type="radio" name="machine" value="60" /></td>
                <td>Humidity</td>
                <td>Shows Humidity readings</td>
                <td>$60</td>
              </tr>

              <tr>
              <td><input type="radio"  name="machine" value="55" /></td>
                <td>Precipitation</td>
                <td>Shows Precipitation readings</td>
                <td>$55</td>
              </tr>
            </table>

<center><button className="btn btn-success">Request New Sensor</button></center>


          </div>
        );
    }


}



export default RequestNewSensor;
