import React, { Component } from 'react';
import './Dashboard.css';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';


class Dashboard extends Component {


    render() {
        return (
          <div className = "d-page">
            <div className="navbar1">
            <ul>
              <li><Link to="/home">Home</Link></li>
              <li><Link to="/reqsensor">Request New Sensor</Link></li>
              <li><Link to="/reqsensor">View Sensor Status</Link></li>
              <li><Link to="/viewsensorlocation">View Sensor Location</Link></li>
              <li><Link to="/payment">Payment</Link></li>
             <li><Link to="/">Logout</Link></li>
            </ul>
            </div>
            <h2><center>Current Sensors</center></h2>
            <table className="sensors">
              <tr>
                <th>Type</th>
                <th>id</th>
                <th>Status</th>
              </tr>
              <tr>
                <td>Temperature</td>
                <td>temp1</td>
                <td>Active</td>
              </tr>
              <tr>
                <td>Pressure</td>
                <td>p1</td>
                <td>Active</td>
              </tr>
              <tr>
                <td>Humidity</td>
                <td>h1</td>
                <td>Active</td>
              </tr>
              <tr>
                <td>Wind</td>
                <td>w1</td>
                <td>Inactive</td>
              </tr>
            </table>

            <button className="btn btn-success addsensorbutton"><Link className="mylink" to="/reqsensor">Add Sensor</Link></button>
            <br />
            <h2><center>Current Packages</center></h2>
            <table className="services">
              <tr>
                <th>Type</th>
                <th>id</th>
                <th>Details</th>
              </tr>
              <tr>
                <td>Package 1</td>
                <td>pack1</td>
                <td>5 tractor 12 sensors</td>
              </tr>
              <tr>
                <td>Package 2</td>
                <td>p2</td>
                <td>4 tractor 9 sensors</td>
              </tr>
            </table>

            <button className="btn btn-success addservicesbutton"><Link className="mylink" to="/reqservice">Add Services</Link></button>
            <br />


            <h2><center>Current Machines</center></h2>
            <table className="machines">
              <tr>
                <th>Type</th>
                <th>id</th>
                <th>Status</th>
              </tr>
              <tr>
                <td>tractor</td>
                <td>tr1</td>
                <td>Active</td>
              </tr>
              <tr>
                <td>Drone</td>
                <td>dr1</td>
                <td>Inactive</td>
              </tr>
              <tr>
                <td>Drone</td>
                <td>dr2</td>
                <td>Active</td>
              </tr>
              <tr>
                <td>Tractor</td>
                <td>tr2</td>
                <td>Inactive</td>
              </tr>
            </table>

            <button className="btn btn-success addmachinebutton"><Link className="mylink" to="/reqmachine">Add Machine</Link></button>
            <br />

          </div>
        );
    }


}



export default Dashboard;
