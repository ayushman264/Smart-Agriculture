import React, { Component } from 'react';
import './RequestNewService.css';
import './RequestNewMachine.css';
import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

class RequestNewMachine extends Component {

    render() {
        return (
          <div className = "reqmachinepage">
          <div className="navbar1">
          <ul>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/reqsensor">Request New Sensor</Link></li>
            <li><Link to="/reqsensor">View Sensor Status</Link></li>
            <li><Link to="/viewsensorlocation">View Sensor Location</Link></li>
            <li><Link to="/payment">Payment</Link></li>
           <li><Link to="/">Logout</Link></li>
          </ul>
          </div>
            <h1><center>View available Machines</center></h1>
            <table>
              <tr>
                <th>Select</th>
                <th>Machine</th>
                <th>Description</th>
                <th>Price(/hr)</th>
                </tr>
              <tr>
                <td><input type="radio" name="machine" value="100" /></td>
                <td>Machine 1</td>
                <td>Tractor</td>
                <td>$100</td>
              </tr>

              <tr>
              <td><input type="radio" name="machine" value="75" /></td>
                <td>Machine 2</td>
                <td>Drone</td>
                <td>$75</td>
              </tr>

              <tr>
              <td><input type="radio" name="machine" value="60" /></td>
                <td>Machine 3</td>
                <td>Sprinkler</td>
                <td>$60</td>
              </tr>

              <tr>
              <td><input type="radio"  name="machine" value="55" /></td>
                <td>Machine 4</td>
                <td>Roller</td>
                <td>$55</td>
              </tr>
            </table>

<center><button className="btn btn-success">Request New Machine</button></center>


          </div>
        );
    }


}



export default RequestNewMachine;
